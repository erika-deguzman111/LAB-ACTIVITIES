<!DOCTYPE html>
<html>
<head>
	<title>welcome</title>
</head>
<body bgcolor="pink">
	<H1>WELCOME TO EARTH</H1>
</body>
</html>